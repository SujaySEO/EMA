Optimised homepage images for escortmarketing.agency (WebP, quality 72, same pixel dimensions and file names as the live files).
Upload paths: files named *-768x*/-1024x* and the 1920px portfolio shots live in /wp-content/uploads/2026/08/ (Best-CMS... is in 2026/11/).
Replace the existing files by name (SFTP/Hostinger file manager, or the Enable Media Replace plugin). Purge LiteSpeed and Cloudflare caches afterwards.
Baseline (before): mobile (390px @3x) 6,157 KB transferred, desktop 1,830 KB, LCP desktop 2.5 s (headless Chromium, no throttling).
Total size of these 14 files: 6,345 KB -> 667 KB.
